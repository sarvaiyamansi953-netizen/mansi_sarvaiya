const express = require('express');
const Product = require('../models/Product');
const Store = require('../models/Store');
const { auth } = require('../middleware/auth');

const router = express.Router();

// GET /api/products
router.get('/', auth, async (req, res) => {
  try {
    const { page = 1, limit = 20, status, search, sortBy = 'totalRevenue', sortOrder = 'desc' } = req.query;
    
    const store = await Store.findOne({ owner: req.user._id }) || await Store.findOne({ isDemo: true });
    if (!store) return res.json({ products: [], total: 0, page: 1, pages: 0 });

    const query = { store: store._id };
    
    if (status && status !== 'all') query.status = status;
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { vendor: { $regex: search, $options: 'i' } },
        { productType: { $regex: search, $options: 'i' } },
      ];
    }

    const total = await Product.countDocuments(query);
    const products = await Product.find(query)
      .sort({ [sortBy]: sortOrder === 'desc' ? -1 : 1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .lean();

    res.json({
      products,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('Products error:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// GET /api/products/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).lean();
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json({ product });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

module.exports = router;
