const express = require('express');
const router = express.Router();
const Store = require('../models/Store');
const User = require('../models/User');
const Order = require('../models/Order');
const { protect, adminOnly } = require('../middleware/auth');

// @desc    Get all stores (Super Admin)
// @route   GET /api/admin/stores
router.get('/stores', protect, adminOnly, async (req, res) => {
  try {
    const stores = await Store.find().populate('owner', 'name email');
    
    // Add some global aggregated metrics for each store
    const storeData = await Promise.all(stores.map(async (store) => {
      const orderCount = await Order.countDocuments({ store: store._id });
      const totalRevenue = await Order.aggregate([
        { $match: { store: store._id } },
        { $group: { _id: null, total: { $sum: '$totalPrice' } } }
      ]);

      return {
        ...store.toObject(),
        orderCount,
        totalRevenue: totalRevenue[0]?.total || 0
      };
    }));

    res.json(storeData);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// @desc    Get global platform stats
// @route   GET /api/admin/stats
router.get('/stats', protect, adminOnly, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalStores = await Store.countDocuments();
    const totalOrders = await Order.countDocuments();
    const globalRevenue = await Order.aggregate([
      { $group: { _id: null, total: { $sum: '$totalPrice' } } }
    ]);

    res.json({
      totalUsers,
      totalStores,
      totalOrders,
      globalRevenue: globalRevenue[0]?.total || 0
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
