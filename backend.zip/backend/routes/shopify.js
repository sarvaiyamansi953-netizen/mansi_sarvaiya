const express = require('express');
const router = express.Router();
const { shopify } = require('../services/shopifyService');
const Store = require('../models/Store');
const User = require('../models/User');

// @desc    Initiate Shopify OAuth
// @route   GET /api/shopify/auth
router.get('/auth', async (req, res) => {
  const shop = req.query.shop;
  if (!shop) return res.status(400).send('Missing shop parameter');

  const authRoute = await shopify.auth.begin({
    shop,
    callbackPath: '/api/shopify/callback',
    isOnline: false,
    rawRequest: req,
    rawResponse: res,
  });
});

// @desc    Shopify OAuth Callback
// @route   GET /api/shopify/callback
router.get('/callback', async (req, res) => {
  try {
    const callback = await shopify.auth.callback({
      rawRequest: req,
      rawResponse: res,
    });

    const { session } = callback;
    const { shop, accessToken } = session;

    // Save or update store in DB
    let store = await Store.findOne({ shop });
    if (!store) {
      store = new Store({
        shop,
        accessToken,
        status: 'active'
      });
      await store.save();
    } else {
      store.accessToken = accessToken;
      await store.save();
    }

    res.redirect(`${process.env.FRONTEND_URL}/dashboard?shop=${shop}`);
  } catch (error) {
    console.error('OAuth Callback Error:', error);
    res.status(500).send('Authentication failed');
  }
});

module.exports = router;
