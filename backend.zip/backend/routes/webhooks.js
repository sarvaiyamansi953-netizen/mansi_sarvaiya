const express = require('express');
const Order = require('../models/Order');
const Store = require('../models/Store');

const router = express.Router();
const { verifyWebhook } = require('../middleware/webhooks');

// Verification middleware for Shopify webhooks
const verifyShopifyWebhook = (req, res, next) => {
  // In production, verify HMAC signature
  next();
};

// @route   POST /api/webhooks/orders/create
router.post('/orders/create', verifyWebhook, async (req, res) => {
  const shopDomain = req.headers['x-shopify-shop-domain'];
  const store = await Store.findOne({ shopifyDomain: shopDomain });
  
  if (!store) return res.status(404).end();

  // Create order in our DB
  const shopifyOrder = req.body;
  const order = new Order({
    store: store._id,
    shopifyOrderId: shopifyOrder.id,
    orderNumber: shopifyOrder.order_number,
    totalPrice: shopifyOrder.total_price,
    currency: shopifyOrder.currency,
    financialStatus: shopifyOrder.financial_status,
    customer: {
      email: shopifyOrder.customer?.email,
      firstName: shopifyOrder.customer?.first_name,
      lastName: shopifyOrder.customer?.last_name
    },
    lineItems: shopifyOrder.line_items.map(li => ({
      title: li.title,
      quantity: li.quantity,
      price: li.price
    })),
    orderDate: shopifyOrder.created_at
  });

  await order.save();
  res.status(200).send('OK');
});

// @route   POST /api/webhooks/products/update
router.post('/products/update', verifyWebhook, async (req, res) => {
  res.status(200).send('OK');
});

module.exports = router;
