const express = require('express');
const { auth } = require('../middleware/auth');
const Store = require('../models/Store');
const Order = require('../models/Order');
const { calculateRoas, calculateClv, analyzeRto } = require('../services/analyticsService');

const router = express.Router();

router.get('/roas', auth, async (req, res) => {
  try {
    const store = await Store.findOne({ owner: req.user._id }) || await Store.findOne({ isDemo: true });
    const { start, end } = req.query;
    
    const startDate = start ? new Date(start) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const endDate = end ? new Date(end) : new Date();

    const data = await calculateRoas(store._id, startDate, endDate);
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'ROAS calculation failed' });
  }
});

router.get('/clv', auth, async (req, res) => {
  try {
    const store = await Store.findOne({ owner: req.user._id }) || await Store.findOne({ isDemo: true });
    const data = await calculateClv(store._id);
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'CLV calculation failed' });
  }
});

router.get('/rto', auth, async (req, res) => {
  try {
    const store = await Store.findOne({ owner: req.user._id }) || await Store.findOne({ isDemo: true });
    const data = await analyzeRto(store._id);
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'RTO analysis failed' });
  }
});

module.exports = router;
