const express = require('express');
const { auth } = require('../middleware/auth');
const Store = require('../models/Store');
const Order = require('../models/Order');
const Product = require('../models/Product');
const { generateInsights } = require('../services/aiService');

const router = express.Router();

router.get('/', auth, async (req, res) => {
  try {
    const store = await Store.findOne({ owner: req.user._id }) || await Store.findOne({ isDemo: true });
    
    // Gather summary data for AI analysis
    const orders = await Order.find({ store: store._id }).limit(100);
    const products = await Product.find({ store: store._id });
    
    const totalRevenue = orders.reduce((sum, o) => sum + o.totalPrice, 0);
    
    const insights = await generateInsights({
      totalRevenue,
      totalOrders: orders.length,
      aov: orders.length > 0 ? totalRevenue / orders.length : 0,
      customerGrowth: 15, // Mocked for now
      channels: ['meta', 'google', 'organic']
    });

    res.json({ insights });
  } catch (error) {
    res.status(500).json({ error: 'AI Insight generation failed' });
  }
});

module.exports = router;
