const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const { protect } = require('../middleware/auth');

// @desc    Export orders/analytics to CSV
// @route   GET /api/analytics/export
router.get('/export', protect, async (req, res) => {
  try {
    const orders = await Order.find({ store: req.user.store }).populate('customer');
    
    let csv = 'Order Number,Date,Customer,Total,Status,Source\n';
    orders.forEach(order => {
      csv += `${order.orderNumber},${order.orderDate.toISOString()},${order.customer?.firstName} ${order.customer?.lastName},${order.totalPrice},${order.financialStatus},${order.source}\n`;
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=store_data_export.csv');
    res.status(200).send(csv);
  } catch (err) {
    res.status(500).json({ message: 'Export failed', error: err.message });
  }
});

module.exports = router;
