const express = require('express');
const Customer = require('../models/Customer');
const Store = require('../models/Store');
const { auth } = require('../middleware/auth');

const router = express.Router();

// GET /api/customers
router.get('/', auth, async (req, res) => {
  try {
    const { page = 1, limit = 20, type, search, sortBy = 'totalSpent', sortOrder = 'desc' } = req.query;
    
    const store = await Store.findOne({ owner: req.user._id }) || await Store.findOne({ isDemo: true });
    if (!store) return res.json({ customers: [], total: 0, page: 1, pages: 0 });

    const query = { store: store._id };
    
    if (type && type !== 'all') query.customerType = type;
    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const total = await Customer.countDocuments(query);
    const customers = await Customer.find(query)
      .sort({ [sortBy]: sortOrder === 'desc' ? -1 : 1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .lean();

    res.json({
      customers,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('Customers error:', error);
    res.status(500).json({ error: 'Failed to fetch customers' });
  }
});

module.exports = router;
