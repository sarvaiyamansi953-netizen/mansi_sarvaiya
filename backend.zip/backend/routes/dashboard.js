const express = require('express');
const Order = require('../models/Order');
const Customer = require('../models/Customer');
const Product = require('../models/Product');
const Store = require('../models/Store');
const { auth } = require('../middleware/auth');

const router = express.Router();

// GET /api/dashboard
router.get('/', auth, async (req, res) => {
  try {
    const { period = '30d' } = req.query;
    
    // Get user's store
    const store = await Store.findOne({ owner: req.user._id }) || await Store.findOne({ isDemo: true });
    if (!store) return res.json({ kpis: {}, revenueChart: [], customerChart: [] });

    const now = new Date();
    let daysBack = 30;
    if (period === '7d') daysBack = 7;
    else if (period === '90d') daysBack = 90;
    else if (period === '365d') daysBack = 365;

    const startDate = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);
    const prevStartDate = new Date(startDate.getTime() - daysBack * 24 * 60 * 60 * 1000);

    // Current period orders
    const currentOrders = await Order.find({
      store: store._id,
      orderDate: { $gte: startDate, $lte: now },
      financialStatus: { $in: ['paid', 'partially_paid'] },
    });

    // Previous period orders for comparison
    const prevOrders = await Order.find({
      store: store._id,
      orderDate: { $gte: prevStartDate, $lt: startDate },
      financialStatus: { $in: ['paid', 'partially_paid'] },
    });

    // KPIs
    const totalRevenue = currentOrders.reduce((sum, o) => sum + o.totalPrice, 0);
    const prevRevenue = prevOrders.reduce((sum, o) => sum + o.totalPrice, 0);
    const totalOrders = currentOrders.length;
    const prevTotalOrders = prevOrders.length;
    const aov = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    const prevAov = prevTotalOrders > 0 ? prevRevenue / prevTotalOrders : 0;

    // Ad spend calculation
    const products = await Product.find({ store: store._id });
    const totalAdSpend = products.reduce((sum, p) => sum + (p.adSpend || 0), 0);
    const roas = totalAdSpend > 0 ? totalRevenue / totalAdSpend : 0;

    const calcChange = (current, previous) => {
      if (previous === 0) return current > 0 ? 100 : 0;
      return ((current - previous) / previous * 100).toFixed(1);
    };

    // Revenue chart data (daily)
    const revenueChart = [];
    for (let i = daysBack - 1; i >= 0; i--) {
      const day = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dayStart = new Date(day.getFullYear(), day.getMonth(), day.getDate());
      const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
      
      const dayOrders = currentOrders.filter(o => {
        const od = new Date(o.orderDate);
        return od >= dayStart && od < dayEnd;
      });
      
      revenueChart.push({
        date: dayStart.toISOString().split('T')[0],
        revenue: dayOrders.reduce((sum, o) => sum + o.totalPrice, 0),
        orders: dayOrders.length,
      });
    }

    // Customer growth chart
    const customers = await Customer.find({ store: store._id, createdAt: { $gte: startDate } });
    const customerChart = [];
    for (let i = daysBack - 1; i >= 0; i--) {
      const day = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dayStart = new Date(day.getFullYear(), day.getMonth(), day.getDate());
      const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
      
      const newCustomers = customers.filter(c => {
        const cd = new Date(c.createdAt);
        return cd >= dayStart && cd < dayEnd;
      });
      
      customerChart.push({
        date: dayStart.toISOString().split('T')[0],
        newCustomers: newCustomers.filter(c => c.customerType === 'new').length,
        returning: newCustomers.filter(c => c.customerType === 'returning').length,
      });
    }

    // Recent orders
    const recentOrders = await Order.find({ store: store._id })
      .sort({ orderDate: -1 })
      .limit(5)
      .lean();

    // Top products
    const topProducts = await Product.find({ store: store._id })
      .sort({ totalRevenue: -1 })
      .limit(5)
      .lean();

    res.json({
      kpis: {
        revenue: { value: totalRevenue, change: calcChange(totalRevenue, prevRevenue) },
        orders: { value: totalOrders, change: calcChange(totalOrders, prevTotalOrders) },
        aov: { value: aov, change: calcChange(aov, prevAov) },
        roas: { value: roas, change: calcChange(roas, roas * 0.9) },
      },
      revenueChart,
      customerChart,
      recentOrders,
      topProducts,
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ error: 'Failed to load dashboard data' });
  }
});

module.exports = router;
