const express = require('express');
const Order = require('../models/Order');
const Store = require('../models/Store');
const { auth } = require('../middleware/auth');

const router = express.Router();

// GET /api/orders
router.get('/', auth, async (req, res) => {
  try {
    const { page = 1, limit = 20, status, search, sortBy = 'orderDate', sortOrder = 'desc' } = req.query;
    
    const store = await Store.findOne({ owner: req.user._id }) || await Store.findOne({ isDemo: true });
    if (!store) return res.json({ orders: [], total: 0, page: 1, pages: 0 });

    const query = { store: store._id };
    
    if (status && status !== 'all') {
      query.financialStatus = status;
    }
    
    if (search) {
      query.$or = [
        { orderNumber: parseInt(search) || 0 },
        { 'customer.firstName': { $regex: search, $options: 'i' } },
        { 'customer.lastName': { $regex: search, $options: 'i' } },
        { 'customer.email': { $regex: search, $options: 'i' } },
      ];
    }

    const total = await Order.countDocuments(query);
    const orders = await Order.find(query)
      .sort({ [sortBy]: sortOrder === 'desc' ? -1 : 1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .lean();

    res.json({
      orders,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('Orders error:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// GET /api/orders/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).lean();
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json({ order });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch order' });
  }
});

module.exports = router;
