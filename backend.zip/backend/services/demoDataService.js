const User = require('../models/User');
const Store = require('../models/Store');
const Order = require('../models/Order');
const Product = require('../models/Product');
const Customer = require('../models/Customer');
const mongoose = require('mongoose');

const seedDemoData = async () => {
  try {
    console.log('🌱 Seeding demo data...');

    // 1. Create Demo Admin
    let admin = await User.findOne({ email: 'admin@demo.com' });
    if (!admin) {
      admin = new User({
        name: 'Demo Admin',
        email: 'admin@demo.com',
        password: 'demo123', // Will be hashed by pre-save hook
        role: 'admin',
        isDemo: true
      });
      await admin.save();
    }

    // 2. Create Demo User
    let demoUser = await User.findOne({ email: 'user@demo.com' });
    if (!demoUser) {
      demoUser = new User({
        name: 'Demo User',
        email: 'user@demo.com',
        password: 'demo123',
        role: 'user',
        isDemo: true
      });
      await demoUser.save();
    }

    // 3. Create Demo Store
    let store = await Store.findOne({ isDemo: true });
    if (!store) {
      store = new Store({
        shopifyDomain: 'demo-store.myshopify.com',
        storeName: 'AI Intelligence Demo',
        owner: admin._id,
        isDemo: true,
        currency: 'USD'
      });
      await store.save();
    }

    // Link store to admin
    if (!admin.connectedStores.includes(store._id)) {
      admin.connectedStores.push(store._id);
      await admin.save();
    }

    // Clear existing demo data
    await Order.deleteMany({ isDemo: true });
    await Product.deleteMany({ isDemo: true });
    await Customer.deleteMany({ isDemo: true });

    // 4. Create Demo Products
    const products = [
      { title: 'Premium Cotton Tee', vendor: 'Apparel Co.', productType: 'Clothing', price: 25, status: 'active', adSpend: 1200, impressions: 45000, clicks: 1200 },
      { title: 'Wireless Noise-Canceling Headphones', vendor: 'Techtronics', productType: 'Electronics', price: 199, status: 'active', adSpend: 3500, impressions: 120000, clicks: 3800 },
      { title: 'Sleek Minimalist Watch', vendor: 'Wrist & Co.', productType: 'Accessories', price: 120, status: 'active', adSpend: 800, impressions: 32000, clicks: 950 },
      { title: 'Eco-Friendly Yoga Mat', vendor: 'ZenFlow', productType: 'Sports', price: 45, status: 'active', adSpend: 500, impressions: 21000, clicks: 680 },
      { title: 'Smart Home Hub', vendor: 'Techtronics', productType: 'Electronics', price: 150, status: 'active', adSpend: 2200, impressions: 85000, clicks: 2100 }
    ];

    const seededProducts = await Product.insertMany(products.map(p => ({
      ...p,
      store: store._id,
      isDemo: true,
      variants: [{ title: 'Default', price: p.price, sku: `SKU-${p.title.substring(0, 3).toUpperCase()}` }],
      totalRevenue: 0,
      totalSales: 0,
      totalOrders: 0
    })));

    // 5. Create Demo Customers
    const sources = ['meta', 'google', 'tiktok', 'email', 'organic', 'direct'];
    const customers = [];
    for (let i = 0; i < 50; i++) {
      customers.push({
        store: store._id,
        firstName: `First${i}`,
        lastName: `Last${i}`,
        email: `customer${i}@example.com`,
        source: sources[Math.floor(Math.random() * sources.length)],
        customerType: i % 5 === 0 ? 'returning' : 'new',
        isDemo: true,
        createdAt: new Date(Date.now() - Math.floor(Math.random() * 90) * 24 * 60 * 60 * 1000)
      });
    }
    const seededCustomers = await Customer.insertMany(customers);

    // 6. Create Demo Orders
    const orders = [];
    const now = new Date();
    
    // Create orders over the last 90 days with some spikes
    for (let i = 0; i < 200; i++) {
      const date = new Date(now.getTime() - Math.floor(Math.random() * 90) * 24 * 60 * 60 * 1000);
      const product = seededProducts[Math.floor(Math.random() * seededProducts.length)];
      const customer = seededCustomers[Math.floor(Math.random() * seededCustomers.length)];
      
      const qty = Math.floor(Math.random() * 3) + 1;
      const total = product.variants[0].price * qty;
      
      orders.push({
        store: store._id,
        orderNumber: 1000 + i,
        totalPrice: total,
        currency: 'USD',
        status: 'paid',
        financialStatus: 'paid',
        fulfillmentStatus: i % 10 === 0 ? 'unfulfilled' : 'fulfilled',
        lineItems: [{
          title: product.title,
          quantity: qty,
          price: product.variants[0].price,
          productId: product._id
        }],
        customer: {
          id: customer._id,
          firstName: customer.firstName,
          lastName: customer.lastName,
          email: customer.email
        },
        source: customer.source,
        paymentMethod: Math.random() > 0.3 ? 'prepaid' : 'cod',
        orderDate: date,
        isDemo: true
      });

      // Update product metrics
      product.totalSales += qty;
      product.totalRevenue += total;
      product.totalOrders += 1;
      
      // Update customer metrics
      customer.ordersCount += 1;
      customer.totalSpent += total;
      customer.lifetimeValue += total;
    }

    await Order.insertMany(orders);
    
    // Save updated products and customers
    await Promise.all(seededProducts.map(p => p.save()));
    await Promise.all(seededCustomers.map(c => c.save()));

    console.log('✅ Demo data seeded successfully!');
    return { admin, demoUser, store };
  } catch (error) {
    console.error('❌ Error seeding demo data:', error);
    throw error;
  }
};

module.exports = { seedDemoData };
