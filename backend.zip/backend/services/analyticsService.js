const Order = require('../models/Order');
const Customer = require('../models/Customer');
const Product = require('../models/Product');

/**
 * Advanced Analytics Computations
 */

const calculateRoas = async (storeId, startDate, endDate) => {
  const orders = await Order.find({
    store: storeId,
    orderDate: { $gte: startDate, $lte: endDate },
    financialStatus: 'paid'
  });

  const products = await Product.find({ store: storeId });
  const totalAdSpend = products.reduce((sum, p) => sum + (p.adSpend || 0), 0);
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalPrice, 0);

  // Platform-wise ROAS
  const breakdown = {
    meta: { revenue: 0, spend: 0 },
    google: { revenue: 0, spend: 0 },
    tiktok: { revenue: 0, spend: 0 },
    other: { revenue: 0, spend: 0 }
  };

  orders.forEach(order => {
    const src = order.source === 'meta' || order.source === 'facebook' || order.source === 'instagram' ? 'meta' :
                order.source === 'google' || order.source === 'adwords' ? 'google' :
                order.source === 'tiktok' ? 'tiktok' : 'other';
    
    breakdown[src].revenue += order.totalPrice;
  });

  // Since we don't have per-platform spend in basic models yet, we'll mock the split
  breakdown.meta.spend = totalAdSpend * 0.5;
  breakdown.google.spend = totalAdSpend * 0.3;
  breakdown.tiktok.spend = totalAdSpend * 0.15;
  breakdown.other.spend = totalAdSpend * 0.05;

  Object.keys(breakdown).forEach(key => {
    breakdown[key].roas = breakdown[key].spend > 0 ? breakdown[key].revenue / breakdown[key].spend : 0;
  });

  return {
    overall: totalAdSpend > 0 ? totalRevenue / totalAdSpend : 0,
    totalRevenue,
    totalAdSpend,
    breakdown
  };
};

const calculateClv = async (storeId) => {
  const customers = await Customer.find({ store: storeId });
  
  if (customers.length === 0) return { avgClv: 0, cohorts: [] };

  const avgClv = customers.reduce((sum, c) => sum + c.lifetimeValue, 0) / customers.length;

  // Simple cohort retention based on first order month
  const cohorts = {};
  customers.forEach(customer => {
    if (!customer.createdAt) return;
    const month = customer.createdAt.toISOString().slice(0, 7); // YYYY-MM
    if (!cohorts[month]) cohorts[month] = { count: 0, revenue: 0 };
    cohorts[month].count++;
    cohorts[month].revenue += customer.lifetimeValue;
  });

  return {
    avgClv,
    cohorts: Object.entries(cohorts).map(([month, data]) => ({
      month,
      customerCount: data.count,
      totalRevenue: data.revenue,
      arpu: data.revenue / data.count
    })).sort((a, b) => b.month.localeCompare(a.month))
  };
};

const analyzeRto = async (storeId) => {
  const cancelledOrders = await Order.find({
    store: storeId,
    fulfillmentStatus: { $in: ['cancelled', 'returned'] }
  });

  const totalOrders = await Order.countDocuments({ store: storeId });
  const rtoRate = totalOrders > 0 ? (cancelledOrders.length / totalOrders) * 100 : 0;

  const reasonBreakdown = {};
  cancelledOrders.forEach(order => {
    const reason = order.cancelReason || 'Unknown';
    reasonBreakdown[reason] = (reasonBreakdown[reason] || 0) + 1;
  });

  const paymentBreakdown = {
    cod: { total: 0, cancelled: 0 },
    prepaid: { total: 0, cancelled: 0 }
  };

  // This would normally need a more complex aggregation, but for demo we filter
  const allOrders = await Order.find({ store: storeId }).limit(500);
  allOrders.forEach(o => {
    const method = o.paymentMethod || 'prepaid';
    if (!paymentBreakdown[method]) return;
    paymentBreakdown[method].total++;
    if (o.fulfillmentStatus === 'cancelled' || o.fulfillmentStatus === 'returned') {
      paymentBreakdown[method].cancelled++;
    }
  });

  return {
    rtoRate,
    count: cancelledOrders.length,
    reasonBreakdown,
    paymentBreakdown: {
      cod: paymentBreakdown.cod.total > 0 ? (paymentBreakdown.cod.cancelled / paymentBreakdown.cod.total) * 100 : 0,
      prepaid: paymentBreakdown.prepaid.total > 0 ? (paymentBreakdown.prepaid.cancelled / paymentBreakdown.prepaid.total) * 100 : 0
    }
  };
};

module.exports = {
  calculateRoas,
  calculateClv,
  analyzeRto
};
