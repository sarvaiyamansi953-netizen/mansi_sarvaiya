const OpenAI = require('openai');

const openai = process.env.OPENAI_API_KEY === 'demo' 
  ? null 
  : new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const generateInsights = async (data) => {
  if (!openai) {
    // Return mock insights if no API key
    return [
      {
        type: 'alert',
        title: 'ROAS Drop Detected',
        content: 'Your overall ROAS has dropped by 15% in the last 7 days. This is primarily driven by a lower CTR on Meta campaigns.',
        severity: 'high',
        action: 'Review Meta ad creatives'
      },
      {
        type: 'success',
        title: 'Top Product Momentum',
        content: 'Premium Cotton Tee has seen a 25% increase in sales this week. Inventory levels are healthy.',
        severity: 'low',
        action: 'Consider scaling ad spend'
      },
      {
        type: 'warning',
        title: 'Customer Retension Dip',
        content: 'Repeat customer rate decreased from 12% to 8.5%. Most churn is happening after the first 30 days.',
        severity: 'medium',
        action: 'Launch an email re-engagement flow'
      }
    ];
  }

  try {
    const prompt = `
      Analyze the following Shopify store data and provide 3-5 actionable marketing insights.
      Data Summary:
      - Total Revenue: ${data.totalRevenue}
      - Total Orders: ${data.totalOrders}
      - Average Order Value: ${data.aov}
      - Top Channels: ${JSON.stringify(data.channels)}
      - Customer Growth: ${data.customerGrowth}%
      
      Format the response as a JSON array of objects with fields: type (alert/warning/success), title, content, severity (high/medium/low), action.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    return JSON.parse(response.choices[0].message.content).insights;
  } catch (error) {
    console.error('OpenAI Error:', error);
    return [{ title: 'AI Engine Unavailable', content: 'Could not generate insights at this time.', type: 'alert', severity: 'low' }];
  }
};

module.exports = { generateInsights };
