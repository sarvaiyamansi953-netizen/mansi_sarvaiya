const { shopifyApi, LATEST_API_VERSION } = require('@shopify/shopify-api');
require('dotenv/config');

// Initialize the Shopify API library
const shopify = shopifyApi({
  apiKey: process.env.SHOPIFY_API_KEY,
  apiSecretKey: process.env.SHOPIFY_API_SECRET,
  scopes: process.env.SHOPIFY_SCOPES.split(','),
  hostName: process.env.HOST?.replace(/https?:\/\//, ''),
  apiVersion: LATEST_API_VERSION,
  isEmbeddedApp: true,
});

const fetchOrders = async (shop, accessToken) => {
  try {
    const client = new shopify.clients.Rest({ shop, accessToken });
    const response = await client.get({ path: 'orders' });
    return response.body.orders;
  } catch (error) {
    console.error(`Error fetching orders for ${shop}:`, error);
    return [];
  }
};

const fetchProducts = async (shop, accessToken) => {
  try {
    const client = new shopify.clients.Rest({ shop, accessToken });
    const response = await client.get({ path: 'products' });
    return response.body.products;
  } catch (error) {
    console.error(`Error fetching products for ${shop}:`, error);
    return [];
  }
};

const fetchCustomers = async (shop, accessToken) => {
  try {
    const client = new shopify.clients.Rest({ shop, accessToken });
    const response = await client.get({ path: 'customers' });
    return response.body.customers;
  } catch (error) {
    console.error(`Error fetching customers for ${shop}:`, error);
    return [];
  }
};

const registerWebhooks = async (shop, accessToken) => {
  try {
    // This requires a real URL and a live Shopify app context
    console.log(`Registering webhooks for ${shop}...`);
    return true;
  } catch (error) {
    console.error(`Error registering webhooks for ${shop}:`, error);
    return false;
  }
};

module.exports = {
  fetchOrders,
  fetchProducts,
  fetchCustomers,
  registerWebhooks,
  shopify // Exporting for use in OAuth flow
};
