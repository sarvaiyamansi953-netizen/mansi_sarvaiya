const crypto = require('crypto');

/**
 * Verify Shopify Webhook HMAC
 */
const verifyWebhook = (req, res, next) => {
  const hmac = req.get('X-Shopify-Hmac-Sha256');
  const body = req.rawBody; // Assumes raw-body middleware is used

  if (!hmac) return res.status(401).send('Missing HMAC');

  const generatedHash = crypto
    .createHmac('sha256', process.env.SHOPIFY_API_SECRET)
    .update(body, 'utf8')
    .digest('base64');

  if (generatedHash !== hmac) {
    console.error('Webhook HMAC verification failed');
    return res.status(401).send('Invalid HMAC');
  }

  next();
};

module.exports = { verifyWebhook };
