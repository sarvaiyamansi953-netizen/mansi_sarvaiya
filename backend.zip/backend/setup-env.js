const fs = require('fs');
const path = require('path');

const envPath = path.join(__dirname, '.env');
const examplePath = path.join(__dirname, '.env.example');

console.log('🚀 Shopify AI Platform - Smart Setup');

if (!fs.existsSync(envPath)) {
  console.log('📝 Creating .env from template...');
  fs.copyFileSync(examplePath, envPath);
  console.log('✅ .env created. Please update it with your MongoDB URI and API keys.');
} else {
  console.log('✅ .env file already exists.');
}

console.log('\n📦 Checking dependencies...');
// This is a stub for potential automated npm installs if environment allowed it.

console.log('\n🎉 Setup complete! Run "npm run dev" to start the engine.');
