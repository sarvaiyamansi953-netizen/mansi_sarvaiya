const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
  store: { type: mongoose.Schema.Types.ObjectId, ref: 'Store', required: true },
  shopifyCustomerId: { type: String },
  firstName: { type: String, required: true },
  lastName: { type: String },
  email: { type: String },
  phone: { type: String },
  ordersCount: { type: Number, default: 0 },
  totalSpent: { type: Number, default: 0 },
  avgOrderValue: { type: Number, default: 0 },
  lastOrderDate: { type: Date },
  firstOrderDate: { type: Date },
  tags: [String],
  source: { type: String, enum: ['web', 'meta', 'google', 'tiktok', 'email', 'organic', 'direct', 'referral'], default: 'web' },
  customerType: { type: String, enum: ['new', 'returning', 'loyal', 'at-risk', 'churned'], default: 'new' },
  city: { type: String },
  country: { type: String },
  lifetimeValue: { type: Number, default: 0 },
  isDemo: { type: Boolean, default: false },
}, { timestamps: true });

customerSchema.index({ store: 1, customerType: 1 });
customerSchema.index({ store: 1, source: 1 });

module.exports = mongoose.model('Customer', customerSchema);
