const mongoose = require('mongoose');

const storeSchema = new mongoose.Schema({
  shopifyDomain: { type: String, required: true, unique: true },
  accessToken: { type: String },
  storeName: { type: String },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  isDemo: { type: Boolean, default: false },
  currency: { type: String, default: 'USD' },
  timezone: { type: String, default: 'America/New_York' },
  plan: { type: String, default: 'basic' },
  webhooksRegistered: { type: Boolean, default: false },
  lastSyncAt: { type: Date },
}, { timestamps: true });

module.exports = mongoose.model('Store', storeSchema);
