const mongoose = require('mongoose');

const lineItemSchema = new mongoose.Schema({
  title: String,
  quantity: Number,
  price: Number,
  sku: String,
  productId: String,
  variantId: String,
});

const orderSchema = new mongoose.Schema({
  store: { type: mongoose.Schema.Types.ObjectId, ref: 'Store', required: true },
  shopifyOrderId: { type: String },
  orderNumber: { type: Number, required: true },
  totalPrice: { type: Number, required: true },
  subtotalPrice: { type: Number },
  totalTax: { type: Number, default: 0 },
  totalDiscount: { type: Number, default: 0 },
  currency: { type: String, default: 'USD' },
  financialStatus: { 
    type: String, 
    enum: ['pending', 'paid', 'partially_paid', 'refunded', 'partially_refunded', 'voided'],
    default: 'paid' 
  },
  fulfillmentStatus: { 
    type: String, 
    enum: ['unfulfilled', 'partial', 'fulfilled', 'cancelled', 'returned'],
    default: 'unfulfilled' 
  },
  lineItems: [lineItemSchema],
  customer: {
    id: String,
    firstName: String,
    lastName: String,
    email: String,
  },
  shippingAddress: {
    city: String,
    province: String,
    country: String,
    zip: String,
  },
  channel: { type: String, enum: ['online', 'pos', 'mobile', 'social'], default: 'online' },
  source: { type: String, enum: ['web', 'meta', 'google', 'tiktok', 'email', 'organic', 'direct', 'referral'], default: 'web' },
  paymentMethod: { type: String, enum: ['prepaid', 'cod'], default: 'prepaid' },
  tags: [String],
  cancelReason: { type: String },
  refundAmount: { type: Number, default: 0 },
  isDemo: { type: Boolean, default: false },
  orderDate: { type: Date, default: Date.now },
}, { timestamps: true });

orderSchema.index({ store: 1, orderDate: -1 });
orderSchema.index({ store: 1, source: 1 });
orderSchema.index({ store: 1, financialStatus: 1 });

module.exports = mongoose.model('Order', orderSchema);
