const mongoose = require('mongoose');

const variantSchema = new mongoose.Schema({
  title: String,
  price: Number,
  compareAtPrice: Number,
  sku: String,
  inventory: { type: Number, default: 0 },
  weight: Number,
});

const productSchema = new mongoose.Schema({
  store: { type: mongoose.Schema.Types.ObjectId, ref: 'Store', required: true },
  shopifyProductId: { type: String },
  title: { type: String, required: true },
  description: { type: String },
  vendor: { type: String },
  productType: { type: String },
  status: { type: String, enum: ['active', 'draft', 'archived'], default: 'active' },
  tags: [String],
  variants: [variantSchema],
  images: [{ src: String, alt: String }],
  totalInventory: { type: Number, default: 0 },
  totalSales: { type: Number, default: 0 },
  totalRevenue: { type: Number, default: 0 },
  totalOrders: { type: Number, default: 0 },
  avgRating: { type: Number, default: 0 },
  adSpend: { type: Number, default: 0 },
  impressions: { type: Number, default: 0 },
  clicks: { type: Number, default: 0 },
  isDemo: { type: Boolean, default: false },
}, { timestamps: true });

productSchema.index({ store: 1, status: 1 });

module.exports = mongoose.model('Product', productSchema);
